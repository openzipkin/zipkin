require 'test_helper'

class TraceSummariesHelperTest < ActionView::TestCase
end
